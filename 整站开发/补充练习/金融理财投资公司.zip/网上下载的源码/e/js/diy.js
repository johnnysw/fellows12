﻿function ChangeColor(color)
 {
   $("sublanmu_content").style.backgroundColor=color;
 }