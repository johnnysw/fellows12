﻿FCKLang.swfuploadBtn = 'Insert/Edit Placeholder';
FCKLang.swfuploadDlgTitle = '图片批量上传';
FCKLang.swfuploadDlgName = 'Placeholder Name';
FCKLang.swfuploadErrNoName = 'Please type the placeholder name';
FCKLang.swfuploadErrNameInUse = 'The specified name is already in use';